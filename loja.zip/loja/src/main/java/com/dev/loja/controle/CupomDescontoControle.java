package com.dev.loja.controle;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.loja.modelos.CupomDesconto;
import com.dev.loja.modelos.Funcionario;
import com.dev.loja.repositorio.CupomDescontoRepositorio;
import com.dev.loja.repositorio.FuncionarioRepositorio;



@Controller
public class CupomDescontoControle {
	@Autowired
	private CupomDescontoRepositorio repositorio;
	@Autowired
	private FuncionarioRepositorio funcionarioRepositorio;
	
	@GetMapping("administrativo/cupomDesconto/cuponsDes")
	public ModelAndView buscarTodos() {
		ModelAndView mv = new ModelAndView("/administrativo/cupomDesconto/cupomDescontoLista");
		mv.addObject("cuponsDesconto", repositorio.findAll());
		return mv;
	}
	
	@GetMapping("/administrativo/cupomDesconto/adicionarCupomDes")
	public ModelAndView add(CupomDesconto cupomDesconto) {
		ModelAndView mv = new ModelAndView("/administrativo/cupomDesconto/cupomDescontoAdicionar");
		mv.addObject("cupomDesconto", cupomDesconto);
		
		List<Funcionario> listaFuncionarios = funcionarioRepositorio.findAll();
		mv.addObject("funcionarios", listaFuncionarios);
		return mv;
	}
	
	@GetMapping("/administrativo/cupomDesconto/editarCupomDes/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		Optional<CupomDesconto> cupomDesconto = repositorio.findById(id);
		CupomDesconto c = cupomDesconto.get();
		return add(c);
	}
	@GetMapping("/administrativo/cupomDesconto/removerCupomDes/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		Optional<CupomDesconto> cupomDesconto = repositorio.findById(id);
		CupomDesconto c = cupomDesconto.get();
		repositorio.delete(c);
		return buscarTodos();
	}
	@PostMapping("/administrativo/cupomDesconto/salvarCupomDes")
	public ModelAndView save(@Valid CupomDesconto cupomDesconto, BindingResult result){
		if(result.hasErrors()) {
			return add(cupomDesconto);
		}
		repositorio.saveAndFlush(cupomDesconto);
		return buscarTodos();
	}
	
	
}
