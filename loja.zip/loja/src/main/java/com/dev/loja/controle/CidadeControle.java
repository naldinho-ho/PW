package com.dev.loja.controle;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.loja.modelos.Cidade;
import com.dev.loja.modelos.Estado;
import com.dev.loja.repositorio.CidadeRepositorio;
import com.dev.loja.repositorio.EstadoRepositorio;



@Controller
public class CidadeControle {
	@Autowired
	private CidadeRepositorio repositorio;
	
	@Autowired
	private EstadoRepositorio repositorioEstado;
	
	@GetMapping("administrativo/cidade/cidades")
	public ModelAndView buscarTodos() {
		
		ModelAndView mv = new ModelAndView("/administrativo/cidade/cidadeLista");
		mv.addObject("cidades", repositorio.findAll());
				
		
		return mv;
	}
	
	@GetMapping("/administrativo/cidade/adicionarCidade")
	public ModelAndView add(Cidade cidade) {
		
		ModelAndView mv = new ModelAndView("/administrativo/cidade/cidadeAdicionar");
		mv.addObject("cidade", cidade);
		
		List<Estado> listaEstado = repositorioEstado.findAll();
		mv.addObject("estados",listaEstado);
		
		return mv;
	}
	
	@GetMapping("/administrativo/cidade/editarCidade/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		
		Optional<Cidade> cidade = repositorio.findById(id);
		Cidade e = cidade.get();	
		
		return add(e);
	}
	
	@GetMapping("/administrativo/cidade/removerCidade/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		
		Optional<Cidade> cidade = repositorio.findById(id);
		Cidade e = cidade.get();
		repositorio.delete(e);	
		
		return buscarTodos();
	}

	@PostMapping("/administrativo/cidade/salvarCidade")
	public ModelAndView save(@Valid Cidade cidade, BindingResult result) {
		
		if(result.hasErrors()) {
			return add(cidade);
		}
		
		repositorio.saveAndFlush(cidade);
		
		return buscarTodos();
	}

}
