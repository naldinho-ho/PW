package com.dev.loja.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dev.loja.modelos.PermissoesFuncionario;


public interface PermissoesFuncionarioRepositorio extends JpaRepository<PermissoesFuncionario, Long>{

}
