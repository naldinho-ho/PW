package com.dev.loja.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dev.loja.modelos.CupomDesconto;


public interface CupomDescontoRepositorio  extends JpaRepository<CupomDesconto, Long>{

}
