package com.dev.loja.controle;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.loja.modelos.Funcionario;
import com.dev.loja.modelos.Papel;
import com.dev.loja.modelos.PermissoesFuncionario;
import com.dev.loja.repositorio.FuncionarioRepositorio;
import com.dev.loja.repositorio.PapelRepositorio;
import com.dev.loja.repositorio.PermissoesFuncionarioRepositorio;


@Controller
public class PermissoesFuncionarioControle {
	@Autowired
	private PermissoesFuncionarioRepositorio repositorio;
	
	@Autowired
	private FuncionarioRepositorio funcionarioRepositorio;
	
	@Autowired
	private PapelRepositorio papelRepositorio;
	

	
	@GetMapping("administrativo/permissoesFuncionario/permissoesFuncionarios")
	public ModelAndView buscarTodos() {
		
		ModelAndView mv = new ModelAndView("/administrativo/permissoesFuncionario/permissoesFuncionarioLista");
		java.util.List<PermissoesFuncionario> listaPermissoesFuncionarios =  repositorio.findAll();
		mv.addObject("permissoesFuncionarios", listaPermissoesFuncionarios);
		mv.addObject("quantidadePermissoesFuncionarios", listaPermissoesFuncionarios.size());
		
		return mv;
	}
	
	
	@GetMapping("/administrativo/permissoesFuncionario/adicionarPermFunc")
	public ModelAndView add(PermissoesFuncionario permissoesFuncionario) {
		
		
		ModelAndView mv = new ModelAndView("/administrativo/permissoesFuncionario/permissoesFuncionarioAdicionar");
		mv.addObject("permissoesFuncionario", permissoesFuncionario);
	
		List<Funcionario> listaFuncionario = funcionarioRepositorio.findAll();
		mv.addObject("funcionarios",listaFuncionario);
		
		List<Papel> listaPapeis = papelRepositorio.findAll();
		mv.addObject("papeis", listaPapeis);
		
		return mv;
	}
	
	@GetMapping("/administrativo/permissoesFuncionario/editarPermissoesFuncionario/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		
		Optional<PermissoesFuncionario> permissoesFuncionario = repositorio.findById(id);
		PermissoesFuncionario e = permissoesFuncionario.get();	
		
		return add(e);
	}
	
	@GetMapping("/administrativo/permissoesFuncionario/removerPermissoesFuncionario/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		
		Optional<PermissoesFuncionario> permissoesFuncionario = repositorio.findById(id);
		PermissoesFuncionario e = permissoesFuncionario.get();
		repositorio.delete(e);	
		
		return buscarTodos();
	}

	@PostMapping("/administrativo/permissoesFuncionario/salvarPermissoesFuncionario")
	public ModelAndView save(@Valid PermissoesFuncionario permissoesFuncionario, BindingResult result) {
		
		repositorio.saveAndFlush(permissoesFuncionario);
		
		return buscarTodos();
	}
	

}
