package com.dev.loja.controle;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.loja.modelos.Cidade;
import com.dev.loja.modelos.Funcionario;
import com.dev.loja.repositorio.CidadeRepositorio;
import com.dev.loja.repositorio.CupomDescontoRepositorio;
import com.dev.loja.repositorio.FuncionarioRepositorio;

@Controller
public class FuncionarioControle {
	
	@Autowired
	private FuncionarioRepositorio repositorio;
	
	@Autowired
	private CidadeRepositorio cidadeRepositorio;
	
	@Autowired
	private CupomDescontoRepositorio cupomDescontoRepositorio;
	
	@GetMapping("administrativo/funcionario/funcionarios")
	public ModelAndView buscarTodos() {
		
		ModelAndView mv = new ModelAndView("/administrativo/funcionario/funcionarioLista");
		java.util.List<Funcionario> listaFuncionarios =  repositorio.findAll();
		mv.addObject("funcionarios", listaFuncionarios);
		mv.addObject("quantidadeFuncionarios", listaFuncionarios.size());
		
		return mv;
	}
	
	@GetMapping("/administrativo/funcionario/adicionarFuncionario")
	public ModelAndView add(Funcionario categoria) {
		
		
		ModelAndView mv = new ModelAndView("/administrativo/funcionario/funcionarioAdicionar");
		mv.addObject("funcionario", categoria);
		List<Cidade> listaCidade = cidadeRepositorio.findAll();
		mv.addObject("cidades",listaCidade);
		

		
		return mv;
	}
	
	@GetMapping("/administrativo/funcionario/editarFuncionario/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		
		Optional<Funcionario> categoria = repositorio.findById(id);
		Funcionario e = categoria.get();	
		
		return add(e);
	}
	
	@GetMapping("/administrativo/funcionario/removerFuncionario/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		
		Optional<Funcionario> categoria = repositorio.findById(id);
		Funcionario e = categoria.get();
		repositorio.delete(e);	
		
		return buscarTodos();
	}

	@PostMapping("/administrativo/funcionario/salvarFuncionario")
	public ModelAndView save(@Valid Funcionario funcionario, BindingResult result) {
		

		
		repositorio.saveAndFlush(funcionario);
		
		return buscarTodos();
	}
	
}

