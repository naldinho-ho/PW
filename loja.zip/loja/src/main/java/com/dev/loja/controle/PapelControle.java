package com.dev.loja.controle;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.loja.modelos.Papel;
import com.dev.loja.repositorio.PapelRepositorio;


@Controller
public class PapelControle {
	@Autowired
	private PapelRepositorio repositorio;
	
	@GetMapping("administrativo/papel/papeis")
	public ModelAndView buscarTodos() {
		
		ModelAndView mv = new ModelAndView("/administrativo/papel/papelLista");
		mv.addObject("papeis", repositorio.findAll());
		
		return mv;
	}
	
	
	@GetMapping("/administrativo/papel/adicionarPapeis")
	public ModelAndView add(Papel papel) {
		
		ModelAndView mv = new ModelAndView("/administrativo/papel/papelAdicionar");
		mv.addObject("papel", papel);
		
		
		return mv;
	}
	
	@GetMapping("/administrativo/papel/editarPapeis/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		
		Optional<Papel> papel = repositorio.findById(id);
		Papel e = papel.get();	
		
		return add(e);
	}
	
	@GetMapping("/administrativo/papel/removerPapeis/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		
		Optional<Papel> papel = repositorio.findById(id);
		Papel e = papel.get();
		repositorio.delete(e);	
		
		return buscarTodos();
	}

	@PostMapping("/administrativo/papel/salvarPapeis")
	public ModelAndView save(@Valid Papel papel, BindingResult result) {
		
		if(result.hasErrors()) {
			return add(papel);
		}
		
		repositorio.saveAndFlush(papel);
		
		return buscarTodos();
	}
	
}

