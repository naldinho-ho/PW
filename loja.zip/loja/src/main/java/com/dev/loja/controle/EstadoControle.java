package com.dev.loja.controle;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.loja.modelos.Estado;
import com.dev.loja.repositorio.EstadoRepositorio;



@Controller
public class EstadoControle {
	@Autowired
	private EstadoRepositorio repositorio;
	
	@GetMapping("administrativo/estado/estados")
	public ModelAndView buscarTodos() {
		
		ModelAndView mv = new ModelAndView("/administrativo/estado/estadoLista");
		mv.addObject("estados", repositorio.findAll());
		
		return mv;
	}
	
	@GetMapping("/administrativo/estado/estadosNome")
	public ModelAndView buscarNome(String nome) {
		
		ModelAndView mv = new ModelAndView("administrativo/estado/estadoLista");
		mv.addObject("estados", repositorio.buscarPorNome(nome));
		
		return mv;
	}
	
	@GetMapping("/administrativo/estado/adicionarEstado")
	public ModelAndView add(Estado estado) {
		
		ModelAndView mv = new ModelAndView("/administrativo/estado/estadoAdicionar");
		mv.addObject("estado", estado);
		
		return mv;
	}
	
	@GetMapping("/administrativo/estado/editarEstado/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		
		Optional<Estado> estado = repositorio.findById(id);
		Estado e = estado.get();	
		
		return add(e);
	}
	
	@GetMapping("/administrativo/estado/removerEstado/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		
		Optional<Estado> estado = repositorio.findById(id);
		Estado e = estado.get();
		repositorio.delete(e);	
		
		return buscarTodos();
	}

	@PostMapping("/administrativo/estado/salvarEstado")
	public ModelAndView save(@Valid Estado estado, BindingResult result) {
		
		if(result.hasErrors()) {
			return add(estado);
		}
		
		repositorio.saveAndFlush(estado);
		
		return buscarTodos();
	}

}
